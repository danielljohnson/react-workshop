# React Workshop

### Setup

- Install node modules `npm install`
- Install bower components `bower install`
- Install gulp `npm install -g gulp`
- Compile JSX and ES6 `gulp` or `gulp watch`
- Browse to the index.html file via localhost (or file system but not recommended)
- If needed you can install and use http-server to run the app `npm install -g http-server` and then `http-server ./` to start