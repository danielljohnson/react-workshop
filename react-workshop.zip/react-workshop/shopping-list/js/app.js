import App from './components/App.react';

React.render(<App/>, document.body);