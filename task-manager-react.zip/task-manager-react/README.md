task-manager-react
==================

A task manager demo using React and Backbone.

### Instructions

- `npm install` and then `node server.js` in server directory
- `npm install`, `bower install` and `gulp` in client directory
- `npm install -g http-server` and then `http-server ./` in client directory
- Browse to http://localhost:8080