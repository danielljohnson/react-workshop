describe('TaskModel', function() {
    'use strict';

    beforeEach(function() {
        
    });

    it('can add', function() {
        expect(1+1).toBe(2);
    });

});