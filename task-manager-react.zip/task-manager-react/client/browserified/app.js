(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";

var _interopRequire = function (obj) { return obj && obj.__esModule ? obj["default"] : obj; };

// components

var Navbar = _interopRequire(require("./Navbar.react"));

var CategoryForm = _interopRequire(require("./CategoryForm.react"));

var TaskForm = _interopRequire(require("./TaskForm.react"));

var TaskList = _interopRequire(require("./TaskList.react"));

var RemoveCompletedTasksButton = _interopRequire(require("./RemoveCompletedTasksButton.react"));

// collections

var CategoryCollection = _interopRequire(require("../domain/CategoryCollection"));

var TaskCollection = _interopRequire(require("../domain/TaskCollection"));

var App = React.createClass({
    displayName: "App",

    // initial state
    getInitialState: function getInitialState() {
        return {
            categories: new CategoryCollection(),
            tasks: new TaskCollection()
        };
    },

    // lifecycle hooks
    componentDidMount: function componentDidMount() {
        var _this = this;

        this.state.categories.fetch();
        this.state.tasks.fetch();

        this.state.categories.on("all", function () {
            _this.setState({ categories: _this.state.categories });
        });

        this.state.tasks.on("all", function () {
            _this.setState({ tasks: _this.state.tasks });
        });
    },

    componentWillUnmount: function componentWillUnmount() {
        this.state.categories.off("all");
        this.state.tasks.off("all");
    },

    // events
    removeCompletedTasks: function removeCompletedTasks(val) {
        this.state.tasks.removeCompleted();
    },

    render: function render() {
        return React.createElement(
            "section",
            null,
            React.createElement(Navbar, { title: "Task Manager" }),
            React.createElement(
                "div",
                { className: "container" },
                React.createElement(
                    "div",
                    { className: "row" },
                    React.createElement(
                        "div",
                        { className: "col-md-5" },
                        React.createElement(TaskList, { categories: this.state.categories, tasks: this.state.tasks })
                    ),
                    React.createElement(
                        "div",
                        { className: "col-md-6 col-md-offset-1" },
                        React.createElement(CategoryForm, { categories: this.state.categories }),
                        React.createElement(TaskForm, { categories: this.state.categories, tasks: this.state.tasks }),
                        React.createElement("hr", null),
                        React.createElement(RemoveCompletedTasksButton, { removeCompletedTasks: this.removeCompletedTasks })
                    )
                )
            )
        );
    }
});

module.exports = App;
},{"../domain/CategoryCollection":8,"../domain/TaskCollection":9,"./CategoryForm.react":2,"./Navbar.react":4,"./RemoveCompletedTasksButton.react":5,"./TaskForm.react":6,"./TaskList.react":7}],2:[function(require,module,exports){
"use strict";

var CategoryForm = React.createClass({
    displayName: "CategoryForm",

    handleSubmit: function handleSubmit(e) {
        e.preventDefault();

        // get form field value
        var category = this.refs.category.getDOMNode().value.trim();

        if (!category) {
            return;
        }

        // save to server
        this.props.categories.create({
            name: category
        });

        // clear form field
        this.refs.category.getDOMNode().value = "";
    },

    render: function render() {
        return React.createElement(
            "form",
            { role: "form", className: "categoryForm", onSubmit: this.handleSubmit },
            React.createElement(
                "h3",
                null,
                "Create Category"
            ),
            React.createElement(
                "div",
                { className: "form-group" },
                React.createElement(
                    "label",
                    null,
                    "Name"
                ),
                React.createElement("input", { type: "text", className: "form-control", ref: "category" })
            ),
            React.createElement(
                "button",
                { type: "submit", className: "btn btn-primary" },
                "Submit"
            )
        );
    }
});

module.exports = CategoryForm;
},{}],3:[function(require,module,exports){
"use strict";

var CategorySelectOption = React.createClass({
    displayName: "CategorySelectOption",

    render: function render() {
        return React.createElement(
            "option",
            { value: this.props.item.get("id") },
            this.props.item.get("name")
        );
    }
});

var CategorySelect = React.createClass({
    displayName: "CategorySelect",

    render: function render() {
        var options = this.props.categories.map(function (item, i) {
            return React.createElement(CategorySelectOption, { item: item, key: i });
        });

        return React.createElement(
            "select",
            { className: "form-control", ref: "category" },
            options
        );
    }
});

module.exports = CategorySelect;
},{}],4:[function(require,module,exports){
"use strict";

var Navbar = React.createClass({
    displayName: "Navbar",

    propTypes: {
        title: React.PropTypes.string.isRequired
    },

    render: function render() {
        return React.createElement(
            "div",
            { className: "navbar navbar-inverse navbar-fixed-top", role: "navigation" },
            React.createElement(
                "div",
                { className: "container" },
                React.createElement(
                    "div",
                    { className: "navbar-header" },
                    React.createElement(
                        "button",
                        { type: "button", className: "navbar-toggle", "data-toggle": "collapse", "data-target": ".navbar-collapse" },
                        React.createElement(
                            "span",
                            { className: "sr-only" },
                            "Toggle navigation"
                        ),
                        React.createElement("span", { className: "icon-bar" }),
                        React.createElement("span", { className: "icon-bar" }),
                        React.createElement("span", { className: "icon-bar" })
                    ),
                    React.createElement(
                        "a",
                        { className: "navbar-brand", href: "#" },
                        this.props.title
                    )
                ),
                React.createElement(
                    "div",
                    { className: "collapse navbar-collapse" },
                    React.createElement("ul", { className: "nav navbar-nav" })
                )
            )
        );
    }
});

module.exports = Navbar;
},{}],5:[function(require,module,exports){
"use strict";

var RemoveCompletedTasksButton = React.createClass({
    displayName: "RemoveCompletedTasksButton",

    render: function render() {
        return React.createElement(
            "button",
            { type: "button", className: "btn btn-primary", onClick: this.props.removeCompletedTasks },
            "Remove Completed"
        );
    }
});

module.exports = RemoveCompletedTasksButton;
},{}],6:[function(require,module,exports){
"use strict";

var _interopRequire = function (obj) { return obj && obj.__esModule ? obj["default"] : obj; };

var CategorySelect = _interopRequire(require("./CategorySelect.react"));

var TaskForm = React.createClass({
    displayName: "TaskForm",

    handleSubmit: function handleSubmit(e) {
        e.preventDefault();

        var task = this.refs.task.getDOMNode().value.trim();
        var category = this.refs.category.getDOMNode().value.trim();

        if (!task || !category) {
            return;
        }

        this.props.tasks.create({
            name: task,
            category: parseInt(category)
        });

        this.refs.task.getDOMNode().value = "";
    },

    render: function render() {
        return React.createElement(
            "form",
            { role: "form", className: "taskForm", onSubmit: this.handleSubmit },
            React.createElement(
                "h3",
                null,
                "Create Task"
            ),
            React.createElement(
                "div",
                { className: "form-group" },
                React.createElement(
                    "label",
                    null,
                    "Name"
                ),
                React.createElement("input", { type: "text", className: "form-control", ref: "task" })
            ),
            React.createElement(
                "div",
                { className: "form-group" },
                React.createElement(
                    "label",
                    null,
                    "Category"
                ),
                React.createElement(CategorySelect, { categories: this.props.categories, ref: "category" })
            ),
            React.createElement(
                "p",
                null,
                React.createElement(
                    "button",
                    { type: "submit", className: "btn btn-primary" },
                    "Submit"
                )
            )
        );
    }
});

module.exports = TaskForm;
},{"./CategorySelect.react":3}],7:[function(require,module,exports){
"use strict";

var CategoryListItem = React.createClass({
    displayName: "CategoryListItem",

    render: function render() {
        var taskList = this.props.tasks.map(function (task, i) {
            return React.createElement(TaskListItem, { key: i, item: task });
        });

        return React.createElement(
            "li",
            null,
            this.props.category.get("name"),
            React.createElement(
                "ul",
                null,
                taskList
            )
        );
    }
});

var TaskListItem = React.createClass({
    displayName: "TaskListItem",

    completeTask: function completeTask(e) {
        e.preventDefault();

        this.props.item.toggleStatus();
    },

    render: function render() {
        return React.createElement(
            "li",
            { "data-status": this.props.item.get("status") },
            React.createElement(
                "a",
                { href: "#", onClick: this.completeTask },
                this.props.item.get("name")
            )
        );
    }
});

var TaskFilter = React.createClass({
    displayName: "TaskFilter",

    render: function render() {
        return React.createElement("input", { type: "text", placeholder: "Filter Tasks", className: "form-control", onKeyUp: this.props.filterTasks.bind(null, this) });
    }
});

var TaskList = React.createClass({
    displayName: "TaskList",

    getInitialState: function getInitialState() {
        return {
            tasks: this.props.tasks.models,
            filteredTasks: this.props.tasks.models
        };
    },

    filterTasks: function filterTasks(val) {
        var query = val.getDOMNode().value.trim();
        var filtered;

        if (query === "") {
            filtered = this.state.tasks;
        } else {
            filtered = this.state.tasks.filter(function (item) {
                return item.get("name").indexOf(query) === 0;
            });
        }

        this.setState({ filteredTasks: filtered });
    },

    render: function render() {
        var _this = this;

        var categoryList = this.props.categories.map(function (category, i) {
            var tasks = _this.state.filteredTasks.filter(function (item) {
                return item.get("category") === category.get("id");
            });

            return React.createElement(CategoryListItem, { key: i, category: category, tasks: tasks });
        });

        return React.createElement(
            "section",
            { className: "taskList" },
            React.createElement(
                "h3",
                null,
                "Task List"
            ),
            React.createElement(TaskFilter, { filterTasks: this.filterTasks }),
            React.createElement(
                "ul",
                null,
                categoryList
            )
        );
    }
});

module.exports = TaskList;
},{}],8:[function(require,module,exports){
"use strict";

var CategoryCollection = Backbone.Collection.extend({
    url: "http://localhost:3000/categories"
});

module.exports = CategoryCollection;
},{}],9:[function(require,module,exports){
"use strict";

var _interopRequire = function (obj) { return obj && obj.__esModule ? obj["default"] : obj; };

var TaskModel = _interopRequire(require("./TaskModel"));

var TaskCollection = Backbone.Collection.extend({
    url: "http://localhost:3000/tasks",

    model: TaskModel,

    removeCompleted: function removeCompleted() {
        var completed = _.filter(this.models, function (task) {
            return task.get("status") === 2;
        });

        _.forEach(completed, function (task) {
            task.destroy();
        });
    }
});

module.exports = TaskCollection;
},{"./TaskModel":10}],10:[function(require,module,exports){
"use strict";

var TaskModel = Backbone.Model.extend({
    urlRoot: "http://localhost:3000/tasks",

    toggleStatus: function toggleStatus() {
        if (this.get("status") === 0) {
            this.set("status", 2);
        } else {
            this.set("status", 0);
        }

        this.save();
    }
});

module.exports = TaskModel;
},{}],11:[function(require,module,exports){
"use strict";

var _interopRequire = function (obj) { return obj && obj.__esModule ? obj["default"] : obj; };

var App = _interopRequire(require("./components/App.react"));

React.render(React.createElement(App, null), document.body);
},{"./components/App.react":1}]},{},[11])