var CategoryCollection = Backbone.Collection.extend({
    url: 'http://localhost:3000/categories'
});

export default CategoryCollection;