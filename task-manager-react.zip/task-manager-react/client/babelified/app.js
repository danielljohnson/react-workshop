"use strict";

var _interopRequire = function (obj) { return obj && obj.__esModule ? obj["default"] : obj; };

var App = _interopRequire(require("./components/App.react"));

React.render(React.createElement(App, null), document.body);