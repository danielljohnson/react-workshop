"use strict";

var _interopRequire = function (obj) { return obj && obj.__esModule ? obj["default"] : obj; };

var TaskModel = _interopRequire(require("./TaskModel"));

var TaskCollection = Backbone.Collection.extend({
    url: "http://localhost:3000/tasks",

    model: TaskModel,

    removeCompleted: function removeCompleted() {
        var completed = _.filter(this.models, function (task) {
            return task.get("status") === 2;
        });

        _.forEach(completed, function (task) {
            task.destroy();
        });
    }
});

module.exports = TaskCollection;