"use strict";

var CategorySelectOption = React.createClass({
    displayName: "CategorySelectOption",

    render: function render() {
        return React.createElement(
            "option",
            { value: this.props.item.get("id") },
            this.props.item.get("name")
        );
    }
});

var CategorySelect = React.createClass({
    displayName: "CategorySelect",

    render: function render() {
        var options = this.props.categories.map(function (item, i) {
            return React.createElement(CategorySelectOption, { item: item, key: i });
        });

        return React.createElement(
            "select",
            { className: "form-control", ref: "category" },
            options
        );
    }
});

module.exports = CategorySelect;