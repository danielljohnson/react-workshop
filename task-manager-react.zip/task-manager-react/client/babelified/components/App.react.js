"use strict";

var _interopRequire = function (obj) { return obj && obj.__esModule ? obj["default"] : obj; };

// components

var Navbar = _interopRequire(require("./Navbar.react"));

var CategoryForm = _interopRequire(require("./CategoryForm.react"));

var TaskForm = _interopRequire(require("./TaskForm.react"));

var TaskList = _interopRequire(require("./TaskList.react"));

var RemoveCompletedTasksButton = _interopRequire(require("./RemoveCompletedTasksButton.react"));

// collections

var CategoryCollection = _interopRequire(require("../domain/CategoryCollection"));

var TaskCollection = _interopRequire(require("../domain/TaskCollection"));

var App = React.createClass({
    displayName: "App",

    // initial state
    getInitialState: function getInitialState() {
        return {
            categories: new CategoryCollection(),
            tasks: new TaskCollection()
        };
    },

    // lifecycle hooks
    componentDidMount: function componentDidMount() {
        var _this = this;

        this.state.categories.fetch();
        this.state.tasks.fetch();

        this.state.categories.on("all", function () {
            _this.setState({ categories: _this.state.categories });
        });

        this.state.tasks.on("all", function () {
            _this.setState({ tasks: _this.state.tasks });
        });
    },

    componentWillUnmount: function componentWillUnmount() {
        this.state.categories.off("all");
        this.state.tasks.off("all");
    },

    // events
    removeCompletedTasks: function removeCompletedTasks(val) {
        this.state.tasks.removeCompleted();
    },

    render: function render() {
        return React.createElement(
            "section",
            null,
            React.createElement(Navbar, { title: "Task Manager" }),
            React.createElement(
                "div",
                { className: "container" },
                React.createElement(
                    "div",
                    { className: "row" },
                    React.createElement(
                        "div",
                        { className: "col-md-5" },
                        React.createElement(TaskList, { categories: this.state.categories, tasks: this.state.tasks })
                    ),
                    React.createElement(
                        "div",
                        { className: "col-md-6 col-md-offset-1" },
                        React.createElement(CategoryForm, { categories: this.state.categories }),
                        React.createElement(TaskForm, { categories: this.state.categories, tasks: this.state.tasks }),
                        React.createElement("hr", null),
                        React.createElement(RemoveCompletedTasksButton, { removeCompletedTasks: this.removeCompletedTasks })
                    )
                )
            )
        );
    }
});

module.exports = App;