"use strict";

var CategoryForm = React.createClass({
    displayName: "CategoryForm",

    handleSubmit: function handleSubmit(e) {
        e.preventDefault();

        // get form field value
        var category = this.refs.category.getDOMNode().value.trim();

        if (!category) {
            return;
        }

        // save to server
        this.props.categories.create({
            name: category
        });

        // clear form field
        this.refs.category.getDOMNode().value = "";
    },

    render: function render() {
        return React.createElement(
            "form",
            { role: "form", className: "categoryForm", onSubmit: this.handleSubmit },
            React.createElement(
                "h3",
                null,
                "Create Category"
            ),
            React.createElement(
                "div",
                { className: "form-group" },
                React.createElement(
                    "label",
                    null,
                    "Name"
                ),
                React.createElement("input", { type: "text", className: "form-control", ref: "category" })
            ),
            React.createElement(
                "button",
                { type: "submit", className: "btn btn-primary" },
                "Submit"
            )
        );
    }
});

module.exports = CategoryForm;