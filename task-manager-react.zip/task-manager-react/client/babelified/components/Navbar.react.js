"use strict";

var Navbar = React.createClass({
    displayName: "Navbar",

    propTypes: {
        title: React.PropTypes.string.isRequired
    },

    render: function render() {
        return React.createElement(
            "div",
            { className: "navbar navbar-inverse navbar-fixed-top", role: "navigation" },
            React.createElement(
                "div",
                { className: "container" },
                React.createElement(
                    "div",
                    { className: "navbar-header" },
                    React.createElement(
                        "button",
                        { type: "button", className: "navbar-toggle", "data-toggle": "collapse", "data-target": ".navbar-collapse" },
                        React.createElement(
                            "span",
                            { className: "sr-only" },
                            "Toggle navigation"
                        ),
                        React.createElement("span", { className: "icon-bar" }),
                        React.createElement("span", { className: "icon-bar" }),
                        React.createElement("span", { className: "icon-bar" })
                    ),
                    React.createElement(
                        "a",
                        { className: "navbar-brand", href: "#" },
                        this.props.title
                    )
                ),
                React.createElement(
                    "div",
                    { className: "collapse navbar-collapse" },
                    React.createElement("ul", { className: "nav navbar-nav" })
                )
            )
        );
    }
});

module.exports = Navbar;