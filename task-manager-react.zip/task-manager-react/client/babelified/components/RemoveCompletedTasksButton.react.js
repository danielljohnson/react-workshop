"use strict";

var RemoveCompletedTasksButton = React.createClass({
    displayName: "RemoveCompletedTasksButton",

    render: function render() {
        return React.createElement(
            "button",
            { type: "button", className: "btn btn-primary", onClick: this.props.removeCompletedTasks },
            "Remove Completed"
        );
    }
});

module.exports = RemoveCompletedTasksButton;