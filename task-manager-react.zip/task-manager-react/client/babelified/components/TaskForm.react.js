"use strict";

var _interopRequire = function (obj) { return obj && obj.__esModule ? obj["default"] : obj; };

var CategorySelect = _interopRequire(require("./CategorySelect.react"));

var TaskForm = React.createClass({
    displayName: "TaskForm",

    handleSubmit: function handleSubmit(e) {
        e.preventDefault();

        var task = this.refs.task.getDOMNode().value.trim();
        var category = this.refs.category.getDOMNode().value.trim();

        if (!task || !category) {
            return;
        }

        this.props.tasks.create({
            name: task,
            category: parseInt(category)
        });

        this.refs.task.getDOMNode().value = "";
    },

    render: function render() {
        return React.createElement(
            "form",
            { role: "form", className: "taskForm", onSubmit: this.handleSubmit },
            React.createElement(
                "h3",
                null,
                "Create Task"
            ),
            React.createElement(
                "div",
                { className: "form-group" },
                React.createElement(
                    "label",
                    null,
                    "Name"
                ),
                React.createElement("input", { type: "text", className: "form-control", ref: "task" })
            ),
            React.createElement(
                "div",
                { className: "form-group" },
                React.createElement(
                    "label",
                    null,
                    "Category"
                ),
                React.createElement(CategorySelect, { categories: this.props.categories, ref: "category" })
            ),
            React.createElement(
                "p",
                null,
                React.createElement(
                    "button",
                    { type: "submit", className: "btn btn-primary" },
                    "Submit"
                )
            )
        );
    }
});

module.exports = TaskForm;