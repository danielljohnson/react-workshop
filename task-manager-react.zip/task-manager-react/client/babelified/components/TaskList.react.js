"use strict";

var CategoryListItem = React.createClass({
    displayName: "CategoryListItem",

    render: function render() {
        var taskList = this.props.tasks.map(function (task, i) {
            return React.createElement(TaskListItem, { key: i, item: task });
        });

        return React.createElement(
            "li",
            null,
            this.props.category.get("name"),
            React.createElement(
                "ul",
                null,
                taskList
            )
        );
    }
});

var TaskListItem = React.createClass({
    displayName: "TaskListItem",

    completeTask: function completeTask(e) {
        e.preventDefault();

        this.props.item.toggleStatus();
    },

    render: function render() {
        return React.createElement(
            "li",
            { "data-status": this.props.item.get("status") },
            React.createElement(
                "a",
                { href: "#", onClick: this.completeTask },
                this.props.item.get("name")
            )
        );
    }
});

var TaskFilter = React.createClass({
    displayName: "TaskFilter",

    render: function render() {
        return React.createElement("input", { type: "text", placeholder: "Filter Tasks", className: "form-control", onKeyUp: this.props.filterTasks.bind(null, this) });
    }
});

var TaskList = React.createClass({
    displayName: "TaskList",

    getInitialState: function getInitialState() {
        return {
            tasks: this.props.tasks.models,
            filteredTasks: this.props.tasks.models
        };
    },

    filterTasks: function filterTasks(val) {
        var query = val.getDOMNode().value.trim();
        var filtered;

        if (query === "") {
            filtered = this.state.tasks;
        } else {
            filtered = this.state.tasks.filter(function (item) {
                return item.get("name").indexOf(query) === 0;
            });
        }

        this.setState({ filteredTasks: filtered });
    },

    render: function render() {
        var _this = this;

        var categoryList = this.props.categories.map(function (category, i) {
            var tasks = _this.state.filteredTasks.filter(function (item) {
                return item.get("category") === category.get("id");
            });

            return React.createElement(CategoryListItem, { key: i, category: category, tasks: tasks });
        });

        return React.createElement(
            "section",
            { className: "taskList" },
            React.createElement(
                "h3",
                null,
                "Task List"
            ),
            React.createElement(TaskFilter, { filterTasks: this.filterTasks }),
            React.createElement(
                "ul",
                null,
                categoryList
            )
        );
    }
});

module.exports = TaskList;